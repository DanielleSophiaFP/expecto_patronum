# **MotorPH Employee Application**

## 📌 **Project Overview**


---

## 📊 **Expected Output**  

## ⚙️ **Features**  


---

## 📂 **File Handling**  


---

## 🚧 **Project Status**  
🔧 **In-progress**  

### 🔍 **Things to Improve**  
-

---

## 👥 **Contributors**  
| Name | GitHub Handle |
|------|--------------|
| Danielle Sophia Pasion | [@DanielleSophiaFP](https://github.com/DanielleSophiaFP) |
| Mico Angelo Uy | [@ocims7](https://github.com/ocims7) |
| Maila Yruma | [@maila02](https://github.com/maila02) |
| James Angeles | [@Jamesangeles-byte](https://github.com/Jamesangeles-byte) |
| Edward Joseph Basilonia | [@EJB0624](https://github.com/EJB0624) |
| Joyce Ann Rodaje | [@yukmwiu](https://github.com/yukmwiu)|

---

🎯 **How to Use:**  

1️⃣ Clone this repository  
```sh
https://github.com/DanielleSophiaFP/super-duper-parakeet.git
```
2️⃣ Run **MotorPH Employee App**










